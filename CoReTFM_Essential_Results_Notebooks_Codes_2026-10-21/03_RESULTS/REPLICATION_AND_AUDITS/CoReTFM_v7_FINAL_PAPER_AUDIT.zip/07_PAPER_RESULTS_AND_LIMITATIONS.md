## CoRe-TFM 160-cache audited result notes

**Scope:** 10 tabular datasets, TabICLv2 and TabPFN-3, 4 randomized held-out split settings per dataset, 128/256 training examples, 205 validation examples (52 used for primary selection), and 128 test examples.

**Main result:** Hard projection reduces marginal inconsistency on the saved predictions, but on average worsens test NLL. This finding does not establish that all coherent postprocessing is harmful.

**Primary fixed hard-projection contrasts:**
- tabiclv2: mean dataset-blocked NLL difference +0.01831, bootstrap 95% [+0.00893, +0.02832], 9/10 datasets harmed, exploratory two-sided Wilcoxon p=0.00977, exploratory Holm p=0.06836.
- tabpfn3: mean dataset-blocked NLL difference +0.01178, bootstrap 95% [+0.00397, +0.01954], 9/10 datasets harmed, exploratory two-sided Wilcoxon p=0.01953, exploratory Holm p=0.13672.

**Interpretation cautions:** Do not infer significance from the 80 split settings. Calibration, candidate selection and gating must be treated as validation-selected methods rather than superior because of individual held-out outcomes.
**Mechanism:** Compare marginal-TV reduction with the paired NLL and Brier difference. Diamonds is a heterogeneous exception; examine the provided split-level and class-pair diagnostics, including sparse cells.
**Provenance:** Exact loaded checkpoint-weight SHA-256 and raw OpenML revision/bytes remain unverified. Processed pickle hashes are not substitutes for raw dataset hashes.
**Submission gate:** Completed saved-prediction audit is not a clean independent rerun of the trained TFMs. An independent pinned-environment rerun and methods documentation are still needed.

All numerical entries are independently computed from raw saved probability arrays. Review every interpretation before manuscript insertion.