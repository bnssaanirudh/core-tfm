"""Deterministic saved-prediction reanalysis. No model inference; no test-label tuning."""
from pathlib import Path
import sys
from zipfile import ZipFile
from io import BytesIO
import numpy as np,pandas as pd,json
from scipy.stats import wilcoxon
HERE=Path(__file__).resolve().parent
EVID=(Path(sys.argv[1]).expanduser() if len(sys.argv)>1 else HERE/'CoReTFM_FULL160_Combined_Verified_Evidence.zip')
if not EVID.is_file():
 raise FileNotFoundError(f'Provide the combined 160-cache ZIP as the first argument: {EVID}')

def norm(x):
 x=np.maximum(np.asarray(x,dtype=np.float64),1e-12)
 return x/x.sum(axis=(1,2),keepdims=True)

def ipf(base,pa,pb,niter=150,tol=1e-9):
 p=norm(base);pa=np.maximum(pa,1e-12);pb=np.maximum(pb,1e-12)
 pa=pa/pa.sum(axis=1,keepdims=True);pb=pb/pb.sum(axis=1,keepdims=True)
 for _ in range(niter):
  p=p*(pa[:,:,None]/np.maximum(p.sum(axis=2,keepdims=True),1e-15))
  p=p*(pb[:,None,:]/np.maximum(p.sum(axis=1,keepdims=True),1e-15))
  if max(float(np.max(np.abs(p.sum(axis=2)-pa))),float(np.max(np.abs(p.sum(axis=1)-pb))))<tol:break
 return norm(p)

def nll_brier(p,yA,yB):
 n,na,nb=p.shape;flat=p.reshape(n,-1)
 lab=yA*nb+yB;q=flat[np.arange(n),lab]
 return float((-np.log(np.maximum(q,1e-12))).mean()),float(((flat*flat).sum(axis=1)+1-2*q).mean())

def tv(p,pa,pb):return float(np.mean(.25*(np.abs(p.sum(axis=2)-pa).sum(axis=1)+np.abs(p.sum(axis=1)-pb).sum(axis=1))))

rows=[]
with ZipFile(EVID) as z:
 for fname in sorted(n for n in z.namelist() if n.startswith('real_caches/') and n.endswith('.npz')):
  m=json.loads(z.read(fname[:-4]+'.json'))
  with np.load(BytesIO(z.read(fname)),allow_pickle=False) as a:
   pa=a['a_test'];pb=a['b_test'];pab=a['a_given_b_test'];pba=a['b_given_a_test']; yA=a['ya_test'];yB=a['yb_test']
  jBA=norm(np.transpose(pab,(0,2,1))*pb[:,None,:]);jAB=norm(pa[:,:,None]*pba)
  ar=norm((jBA+jAB)*.5)
  geo=norm(np.sqrt(np.maximum(jBA,1e-12)*np.maximum(jAB,1e-12)))
  arhard=ipf(ar,pa,pb);geohard=ipf(geo,pa,pb)
  a_nll,a_brier=nll_brier(ar,yA,yB)
  g_nll,g_brier=nll_brier(geo,yA,yB)
  h_nll,h_brier=nll_brier(arhard,yA,yB)
  gh_nll,gh_brier=nll_brier(geohard,yA,yB)
  rows.append({'dataset':m['dataset'],'model':m['model'],'seed':int(m['seed']),'fold':int(m['fold']),'train_cap':int(m['train_cap']),
   'arithmetic_nll':a_nll,'geometric_nll':g_nll,'hard_arithmetic_nll':h_nll,'hard_geometric_nll':gh_nll,
   'hard_arithmetic_minus_arithmetic_nll':h_nll-a_nll,'hard_geometric_minus_arithmetic_nll':gh_nll-a_nll,
   'hard_geometric_minus_geometric_nll':gh_nll-g_nll,
   'hard_geometric_minus_hard_arithmetic_nll':gh_nll-h_nll,
   'arithmetic_brier':a_brier,'geometric_brier':g_brier,'hard_arithmetic_brier':h_brier,'hard_geometric_brier':gh_brier,
   'hard_arithmetic_marginal_tv':tv(arhard,pa,pb),'hard_geometric_marginal_tv':tv(geohard,pa,pb),'pool_marginal_tv':tv(ar,pa,pb)})
df=pd.DataFrame(rows); assert len(df)==160
df.to_csv(HERE/'BRIDGE_PROJECTION_CONFIGURATION_SCORES.csv',index=False)
primary=df[df.train_cap==256]
dset=primary.groupby(['model','dataset'],as_index=False).mean(numeric_only=True)
dset.to_csv(HERE/'BRIDGE_PROJECTION_DATASET_BLOCKS.csv',index=False)
stats=[]
for model,g in dset.groupby('model'):
 selected=primary[primary.model==model]
 for method,col in [('arithmetic_reference','hard_arithmetic_minus_arithmetic_nll'),('geometric_reference_vs_arithmetic_pool','hard_geometric_minus_arithmetic_nll'),('geometric_reference_vs_geometric_pool','hard_geometric_minus_geometric_nll'),('geometric_reference_vs_arithmetic_reference','hard_geometric_minus_hard_arithmetic_nll')]:
  v=g[col].to_numpy();p=float(wilcoxon(v).pvalue) if np.any(v) else 1.
  rng=np.random.default_rng(20261020)
  boots=rng.choice(v,size=(20000,len(v)),replace=True).mean(axis=1)
  stats.append({'model':model,'comparison':method,'n_datasets':len(v),'mean_delta_nll':float(v.mean()),'n_dataset_harmed':int((v>0).sum()),'n_dataset_improved':int((v<0).sum()),'mean_over_configs':float(selected[col].mean()),'n_configs_harmed':int((selected[col]>0).sum()),'ci95_low':float(np.quantile(boots,.025)),'ci95_high':float(np.quantile(boots,.975)),'wilcoxon_two_sided_p_exploratory':p})
summary=pd.DataFrame(stats);summary.to_csv(HERE/'BRIDGE_PROJECTION_SUMMARY.csv',index=False)
assert df['hard_arithmetic_marginal_tv'].max()<1e-3,df['hard_arithmetic_marginal_tv'].max()
assert df['hard_geometric_marginal_tv'].max()<1e-3,df['hard_geometric_marginal_tv'].max()
print(summary.to_string(index=False,float_format=lambda x:f'{x:.6f}'))
