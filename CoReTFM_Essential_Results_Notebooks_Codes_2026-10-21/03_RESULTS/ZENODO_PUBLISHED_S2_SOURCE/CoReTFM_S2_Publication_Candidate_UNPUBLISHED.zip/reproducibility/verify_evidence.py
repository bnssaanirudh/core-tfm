from pathlib import Path
import sys
from zipfile import ZipFile
from io import BytesIO
import json,hashlib,numpy as np,pandas as pd
p=(Path(sys.argv[1]).expanduser() if len(sys.argv)>1 else Path(__file__).with_name('CoReTFM_FULL160_Combined_Verified_Evidence.zip'))
if not p.is_file():
 raise FileNotFoundError(f'Provide the evidence ZIP path as argument: {p}')
result={'input_archive':p.name,'archive_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'manifest_verified':0,'prediction_caches_verified':0,'heldout_overlap_failures':0,'probability_checks_passed':0,'checkpoint_weight_shas_verified':0,'datasets':[],'models':[]}
with ZipFile(p) as z:
 assert z.testzip() is None
 ns=set(z.namelist());manifest=json.loads(z.read('COMBINED_SHA256_MANIFEST.json'))
 for e in manifest:
  assert e['path'] in ns,e['path']
  b=z.read(e['path']);assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
  result['manifest_verified']+=1
 datasets=set();models=set();caps=[]
 for f in sorted(x for x in ns if x.startswith('real_caches/') and x.endswith('.npz')):
  meta=json.loads(z.read(f[:-4]+'.json'))
  b=z.read(f); assert hashlib.sha256(b).hexdigest()==meta['npz_sha256']
  with np.load(BytesIO(b),allow_pickle=False) as a:
   for kind in ('a','b','a_given_b','b_given_a'):
    for role in ('val','test'):
     v=a[f'{kind}_{role}'];assert np.isfinite(v).all() and np.allclose(v.sum(axis=-1),1,atol=1e-4)
   ids=[set(a[x+'_ids'].tolist()) for x in ('train','val','test')]
   assert not ids[0]&ids[1] and not ids[0]&ids[2] and not ids[1]&ids[2]
   assert len(a['test_ids'])==128 and len(a['val_ids'])==205
  result['prediction_caches_verified']+=1;result['probability_checks_passed']+=1
  datasets.add(meta['dataset']);models.add(meta['model']);caps.append(meta['train_cap'])
  if meta.get('checkpoint_revision_confirmed') is True and meta.get('checkpoint_sha256') not in ('NOT_VERIFIED',None):result['checkpoint_weight_shas_verified']+=1
 result['datasets']=sorted(datasets);result['models']=sorted(models);result['training_caps']=sorted(set(caps));result['split_count']=len([f for f in ns if f.startswith('splits/') and f.endswith('.json')])
assert result['manifest_verified']==414
assert result['prediction_caches_verified']==160
assert result['split_count']==40
Path(__file__).with_name('NEW_EVIDENCE_INTEGRITY_AUDIT.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
